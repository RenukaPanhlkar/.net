﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Banking
{
    public class Service1 : IService1
    {
        public bool Deposit(string accountId, int amount)
        {
            bool status = false;

            //get Account Detais from database using ado.net/ entity framework/ Serialization
            //change Balance by adding amount to that Account
            //update Account Details inside database ado.net/ entity framework/ Serialization

            return status;
            
        }

        public Account GetAccountDetails(string acctId)
        {
            Account account = null;
            //get Account Detais from database using ado.net/ entity framework/ Serialization
            switch (acctId)
            {
                case "123":
                    account=new Account() {  AccountId = "123" ,Name="Raj Kapoor", Balance=56000 };
                    break;
                case "456":
                    account = new Account() { AccountId = "456", Name = "Ranbeer Kapoor", Balance = 256000 };
                    break;
            }
            return account;  
        }

        public bool Withdraw(string accountId, int amount)
        {
            bool status = false;

            //get Account Detais from database using ado.net/ entity framework/ Serialization
            //change Balance by removeing amount to that Account
            //update Account Details inside database ado.net/ entity framework/ Serialization
            return status;
        }
    }
}
