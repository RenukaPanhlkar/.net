﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace Banking
{
    [ServiceContract]
    public interface IService1
    {
        [OperationContract]
        bool Withdraw(string accountId, int amount);

        [OperationContract]
        bool Deposit(string accountId, int amount);

        [OperationContract]
        Account GetAccountDetails(string acctId);
    }

 
    [DataContract]
    public class Account
    {
        [DataMember]
        public string AccountId { get; set; }
        [DataMember]
        public string Name { get; set; }

        [DataMember]
        public double Balance { get; set; }
    }
}
