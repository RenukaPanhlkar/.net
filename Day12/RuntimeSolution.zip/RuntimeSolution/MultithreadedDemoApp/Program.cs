﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;


namespace MultithreadedDemoApp
{
    internal class Program
    {

        static void Task2()
        {
            string name = "KnowIT";
            bool status = false;

            Console.WriteLine(name);


            Thread th = Thread.CurrentThread;
            Console.WriteLine(th.ToString());
            Console.WriteLine(th.ManagedThreadId);
            Console.WriteLine(th.Name);
            Console.WriteLine(th.Priority);
            Thread.Sleep(6000);

            Console.WriteLine("Resumed Thread after 6000 milisenconds and continuing work pending in function");
            int count = 56;
            count++;
            if(count ==100)
            {

            }


        }
        static void Task1()
        {
            string name = "Transflower";
            bool status = false;


            //Critical Section
            //Resource Sharing problem

            //file IO OPerations 
            FileStream fs = new FileStream(@"D:\try\myfile.txt", FileMode.OpenOrCreate);
            //Thread Synchronization
            lock (fs)
            {
                BinaryFormatter bf = new BinaryFormatter();
                Person prn = new Person("Shital", "Kulkarni");
                bf.Serialize(fs, prn);
                fs.Close();
            }
            
            int count = 0;
            if(count != 100)
            {
                count++;
            }

            Thread th = Thread.CurrentThread;
            Console.WriteLine(th.ToString());
            Console.WriteLine(th.ManagedThreadId);
            Console.WriteLine(th.Name);
            Console.WriteLine(th.Priority);

    

        }
        static void Main(string[] args)
        {
            int count = 45;
            count++;
            Console.WriteLine(count);
            Person person = new Person();
            person.FirstName = "Manish";
            person.LastName = "Sharma";

            Thread th=Thread.CurrentThread;
            Console.WriteLine(th.ToString());
            Console.WriteLine(th.ManagedThreadId);
            Console.WriteLine(th.Name);
            Console.WriteLine(th.Priority);

            //Secondary Threads

            ThreadStart thread1Delegate = new ThreadStart(Task1);
            ThreadStart thread2Delegate = new ThreadStart(Task1);

            Thread thread1 = new Thread(thread1Delegate);
            Thread thread2 = new Thread(thread2Delegate);

            thread1.Start();
            thread2.Start();


            Console.ReadLine();

        }
    }
}
