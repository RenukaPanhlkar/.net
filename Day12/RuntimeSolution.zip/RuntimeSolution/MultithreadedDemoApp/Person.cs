﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Threading;
namespace MultithreadedDemoApp
{
    public class Person
    {
        public Person()
        {
            this.FirstName = "Ravi";
            this.LastName = "Tambade";
        }
        public Person(string fname, string lname)
        {
            this.FirstName = fname;
            this.LastName = lname;
        }
        public string FirstName { get; set; }   
        public string LastName { get; set; }

        ~Person()
        {
            //auto cleanup code during finalizing object by Garbage Collector
            Thread th = Thread.CurrentThread;
            Console.WriteLine(th.ToString());
            Console.WriteLine(th.ManagedThreadId);
            Console.WriteLine(th.Name);
            Console.WriteLine(th.Priority);
        
        }

    }
}
