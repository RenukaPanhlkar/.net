﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.ServiceModel;
using System.ServiceModel.Web;
using System.Text;

namespace CRM
{
    [ServiceContract]
    public interface IService1
    {

        [OperationContract]
        Customer GetCustomerDetails(string customerId);
        [OperationContract]
        bool Register(Customer cst);

        [OperationContract]
        bool UnRegister(Customer cst);
 

        // TODO: Add your service operations here
    }


    // Use a data contract as illustrated in the sample below to add composite types to service operations.
    [DataContract]
    public class Customer
    {
        [DataMember]
        public string CustomerId { get; set; }

        [DataMember]
        public string FirstName { get; set; }

        [DataMember]
        public string LastName { get; set; }

        [DataMember]
        public string Email { get; set; }

        [DataMember]
        public string ContactNumber { get; set; }


    }
}
