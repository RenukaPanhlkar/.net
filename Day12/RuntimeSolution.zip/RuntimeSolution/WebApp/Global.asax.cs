using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace WebApp
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            this.Application["company"] = "Transflower";
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }

        protected  void Session_Start()
        {
            this.Session["visits"] = 0;

        }

        protected  void Session_End()
        {   
            this.Session.Clear(); 


        }
        protected void Application_End()
        {

            //Application level cleanup code  to be written here.

        }
        protected void Application_Error()
        {

            // Code to handle runtime exception occured anywhere in asp.net application

        }
    }
}
