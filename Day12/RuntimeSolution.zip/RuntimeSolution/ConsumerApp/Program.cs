﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsumerApp
{
    internal class Program
    {
        static void Main(string[] args)
        {
            CRMServiceReference.IService1 crmService=new CRMServiceReference.Service1Client(); // proxy objecty
            CRMServiceReference.Customer theCustomer = crmService.GetCustomerDetails("123");
            Console.WriteLine("Customer Details: ");
            Console.WriteLine(theCustomer.FirstName + " " + theCustomer.LastName + " " + theCustomer.CustomerId);

            BankingServiceReference.IService1 bankingService = new BankingServiceReference.Service1Client();
            BankingServiceReference.Account acct = bankingService.GetAccountDetails("456");
            Console.WriteLine("Account  Details: ");
            Console.WriteLine(acct.Name + " " +acct.AccountId + " " + acct.Balance);

            Console.ReadLine();

        }
    }
}
