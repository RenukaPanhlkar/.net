using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;
using System.Web.Routing;

namespace TFLWebApp
{
    public class MvcApplication : System.Web.HttpApplication
    {
        protected void Application_Start()
        {
            AreaRegistration.RegisterAllAreas();
            RouteConfig.RegisterRoutes(RouteTable.Routes);
        }

        protected void Session_Start()
        {
            this.Session["visits"] = 0;
            this.Session["shoppingcart"] = new List<string>();
            this.Session["isAuthenticated"] = false;
        }

        protected void Session_End()
        {
            this.Session["visits"] = 0;
            this.Session.Clear();
        }

        protected void Application_End()
        {
             //auto clean up code before application getting removed from server

        }
    }
}
